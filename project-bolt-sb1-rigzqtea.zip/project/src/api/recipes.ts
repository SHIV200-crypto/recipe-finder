const API_KEY = '4887dc1a6a314bdaacab02ea48e1956e';
const BASE_URL = 'https://api.spoonacular.com/recipes';

export async function searchRecipes(query: string) {
  const response = await fetch(
    `${BASE_URL}/complexSearch?apiKey=${API_KEY}&query=${query}&number=9`
  );
  const data = await response.json();
  return data.results;
}

export async function getRecipeDetails(id: number) {
  const response = await fetch(
    `${BASE_URL}/${id}/information?apiKey=${API_KEY}`
  );
  const data = await response.json();
  return data;
}