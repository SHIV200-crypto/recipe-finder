export const sampleRecipes = [
  {
    id: '1',
    title: 'Classic Margherita Pizza',
    image: 'https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?auto=format&fit=crop&w=800',
    ingredients: ['Pizza dough', 'Tomato sauce', 'Fresh mozzarella', 'Fresh basil', 'Olive oil'],
    instructions: 'Roll out dough, spread sauce, add cheese, bake at 450°F for 12-15 minutes, garnish with basil.',
    isFavorite: false
  },
  {
    id: '2',
    title: 'Chocolate Chip Cookies',
    image: 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=800',
    ingredients: ['Flour', 'Butter', 'Brown sugar', 'Chocolate chips', 'Eggs', 'Vanilla extract'],
    instructions: 'Cream butter and sugar, add eggs and vanilla, mix in dry ingredients, fold in chocolate chips, bake at 375°F for 10-12 minutes.',
    isFavorite: false
  },
  {
    id: '3',
    title: 'Fresh Garden Salad',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800',
    ingredients: ['Mixed greens', 'Cherry tomatoes', 'Cucumber', 'Red onion', 'Balsamic vinaigrette'],
    instructions: 'Wash and chop vegetables, combine in a bowl, toss with vinaigrette.',
    isFavorite: false
  }
];