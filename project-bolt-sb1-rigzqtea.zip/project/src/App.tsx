import React, { useState, useEffect } from 'react';
import { Search, ChefHat } from 'lucide-react';
import { RecipeCard } from './components/RecipeCard';
import { RecipeModal } from './components/RecipeModal';
import { searchRecipes, getRecipeDetails } from './api/recipes';
import { Recipe, SearchResult } from './types';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [recipes, setRecipes] = useState<SearchResult[]>([]);
  const [favorites, setFavorites] = useState<SearchResult[]>([]);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState(false);
  const [showFavorites, setShowFavorites] = useState(false);

  useEffect(() => {
    const savedFavorites = localStorage.getItem('favorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
    // Load initial recipes
    loadInitialRecipes();
  }, []);

  const loadInitialRecipes = async () => {
    setLoading(true);
    try {
      // Load a mix of different cuisines for variety
      const promises = [
        searchRecipes('italian pasta'),
        searchRecipes('asian stir fry'),
        searchRecipes('mexican tacos')
      ];
      const results = await Promise.all(promises);
      // Take 3 recipes from each cuisine type and combine them
      const combinedRecipes = results.flatMap(result => 
        result.slice(0, 3)
      );
      setRecipes(combinedRecipes);
    } catch (error) {
      console.error('Error loading initial recipes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    try {
      const results = await searchRecipes(searchQuery);
      setRecipes(results);
    } catch (error) {
      console.error('Error searching recipes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRecipeClick = async (id: number) => {
    try {
      const details = await getRecipeDetails(id);
      setSelectedRecipe({ ...details, isFavorite: favorites.some(fav => fav.id === id) });
    } catch (error) {
      console.error('Error fetching recipe details:', error);
    }
  };

  const toggleFavorite = (recipe: SearchResult) => {
    const newFavorites = favorites.some(fav => fav.id === recipe.id)
      ? favorites.filter(fav => fav.id !== recipe.id)
      : [...favorites, recipe];
    
    setFavorites(newFavorites);
    localStorage.setItem('favorites', JSON.stringify(newFavorites));
  };

  const displayedRecipes = showFavorites ? favorites : recipes;

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-12 text-center">
          <div className="flex justify-center mb-4">
            <ChefHat className="w-16 h-16 text-red-500" />
          </div>
          <h1 className="text-5xl font-bold mb-6 text-gray-800">Recipe Finder</h1>
          
          {/* Beautiful Quote Section */}
          <div className="max-w-3xl mx-auto mb-12 px-4">
            <blockquote className="text-2xl font-serif italic text-gray-600 relative py-8">
              <div className="absolute top-0 left-0 transform -translate-x-4 -translate-y-4 text-6xl text-red-200">"</div>
              <p className="relative z-10">
                Cooking is like love. It should be entered into with abandon or not at all.
              </p>
              <footer className="text-lg mt-4 text-gray-500">- Harriet Van Horne</footer>
              <div className="absolute bottom-0 right-0 transform translate-x-4 translate-y-4 text-6xl text-red-200">"</div>
            </blockquote>
          </div>
          
          <div className="flex gap-4 mb-6 max-w-3xl mx-auto">
            <div className="flex-1 flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  placeholder="Search for recipes..."
                  className="w-full px-4 py-3 rounded-lg border focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none text-lg"
                />
                <button
                  onClick={handleSearch}
                  disabled={loading}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <Search className="w-6 h-6 text-gray-500" />
                </button>
              </div>
            </div>
            
            <button
              onClick={() => setShowFavorites(!showFavorites)}
              className={`px-6 py-2 rounded-lg font-medium transition-colors ${
                showFavorites 
                  ? 'bg-red-500 text-white hover:bg-red-600' 
                  : 'bg-white text-gray-800 hover:bg-gray-50'
              }`}
            >
              {showFavorites ? 'Show All' : 'Favorites'}
            </button>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto"></div>
          </div>
        ) : (
          <>
            {!showFavorites && searchQuery === '' && (
              <div className="mb-8">
                <h2 className="text-2xl font-semibold mb-2 text-gray-700">Discover Delicious Recipes</h2>
                <p className="text-gray-600 mb-6">Explore our curated collection of mouthwatering dishes from around the world</p>
              </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {displayedRecipes.map((recipe) => (
                <RecipeCard
                  key={recipe.id}
                  recipe={recipe}
                  isFavorite={favorites.some(fav => fav.id === recipe.id)}
                  onToggleFavorite={toggleFavorite}
                  onClick={handleRecipeClick}
                />
              ))}
            </div>
          </>
        )}

        {displayedRecipes.length === 0 && !loading && (
          <div className="text-center py-12 text-gray-500">
            {showFavorites 
              ? "No favorite recipes yet. Add some recipes to your favorites!"
              : "No recipes found. Try a different search term!"}
          </div>
        )}

        {selectedRecipe && (
          <RecipeModal
            recipe={selectedRecipe}
            onClose={() => setSelectedRecipe(null)}
          />
        )}
      </div>
    </div>
  );
}

export default App;