import React from 'react';
import { Heart } from 'lucide-react';
import { Recipe, SearchResult } from '../types';

interface RecipeCardProps {
  recipe: SearchResult;
  isFavorite: boolean;
  onToggleFavorite: (recipe: SearchResult) => void;
  onClick: (id: number) => void;
}

export function RecipeCard({ recipe, isFavorite, onToggleFavorite, onClick }: RecipeCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <img 
        src={recipe.image} 
        alt={recipe.title} 
        className="w-full h-48 object-cover cursor-pointer"
        onClick={() => onClick(recipe.id)}
      />
      <div className="p-4">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold line-clamp-2">{recipe.title}</h3>
          <button 
            onClick={() => onToggleFavorite(recipe)}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
          >
            <Heart 
              className={`w-6 h-6 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-400'}`}
            />
          </button>
        </div>
      </div>
    </div>
  );
}