export interface Recipe {
  id: number;
  title: string;
  image: string;
  summary: string;
  instructions: string;
  extendedIngredients: {
    original: string;
  }[];
  isFavorite: boolean;
}

export interface SearchResult {
  id: number;
  title: string;
  image: string;
}